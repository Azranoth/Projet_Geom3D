/** Projet - Géométrie pour la 3D - 2016/2017 **/
/** ------- Audric WASMER - L3S6 CMI -------- **/

#include "meshquad.h"
#include "matrices.h"

MeshQuad::MeshQuad():
	m_nb_ind_edges(0)
{

}


void MeshQuad::gl_init()
{
	m_shader_flat = new ShaderProgramFlat();
	m_shader_color = new ShaderProgramColor();

	//VBO
	glGenBuffers(1, &m_vbo);

	//VAO
	glGenVertexArrays(1, &m_vao);
	glBindVertexArray(m_vao);
	glBindBuffer(GL_ARRAY_BUFFER, m_vbo);
	glEnableVertexAttribArray(m_shader_flat->idOfVertexAttribute);
	glVertexAttribPointer(m_shader_flat->idOfVertexAttribute, 3, GL_FLOAT, GL_FALSE, 0, 0);
	glBindVertexArray(0);

	glGenVertexArrays(1, &m_vao2);
	glBindVertexArray(m_vao2);
	glBindBuffer(GL_ARRAY_BUFFER, m_vbo);
	glEnableVertexAttribArray(m_shader_color->idOfVertexAttribute);
	glVertexAttribPointer(m_shader_color->idOfVertexAttribute, 3, GL_FLOAT, GL_FALSE, 0, 0);
	glBindVertexArray(0);


	//EBO indices
	glGenBuffers(1, &m_ebo);
    glGenBuffers(1, &m_ebo2);
}

void MeshQuad::gl_update()
{
	//VBO
	glBindBuffer(GL_ARRAY_BUFFER, m_vbo);
	glBufferData(GL_ARRAY_BUFFER, 3 * m_points.size() * sizeof(GLfloat), &(m_points[0][0]), GL_STATIC_DRAW);
	glBindBuffer(GL_ARRAY_BUFFER, 0);


	std::vector<int> tri_indices;
	convert_quads_to_tris(m_quad_indices,tri_indices);

	//EBO indices
	glBindBuffer(GL_ELEMENT_ARRAY_BUFFER, m_ebo);
	glBufferData(GL_ELEMENT_ARRAY_BUFFER,tri_indices.size() * sizeof(int), &(tri_indices[0]), GL_STATIC_DRAW);
	glBindBuffer(GL_ELEMENT_ARRAY_BUFFER, 0);


	std::vector<int> edge_indices;
	convert_quads_to_edges(m_quad_indices,edge_indices);
	m_nb_ind_edges = edge_indices.size();

	glBindBuffer(GL_ELEMENT_ARRAY_BUFFER, m_ebo2);
	glBufferData(GL_ELEMENT_ARRAY_BUFFER,m_nb_ind_edges * sizeof(int), &(edge_indices[0]), GL_STATIC_DRAW);
	glBindBuffer(GL_ELEMENT_ARRAY_BUFFER, 0);
}



void MeshQuad::set_matrices(const Mat4& view, const Mat4& projection)
{
	viewMatrix = view;
	projectionMatrix = projection;
}

void MeshQuad::draw(const Vec3& color)
{

	glEnable(GL_POLYGON_OFFSET_FILL);
	glPolygonOffset(1.0f, 1.0f);

	m_shader_flat->startUseProgram();
	m_shader_flat->sendViewMatrix(viewMatrix);
	m_shader_flat->sendProjectionMatrix(projectionMatrix);
	glUniform3fv(m_shader_flat->idOfColorUniform, 1, glm::value_ptr(color));
	glBindVertexArray(m_vao);
	glBindBuffer(GL_ELEMENT_ARRAY_BUFFER,m_ebo);
	glDrawElements(GL_TRIANGLES, 3*m_quad_indices.size()/2,GL_UNSIGNED_INT,0);
	glBindBuffer(GL_ELEMENT_ARRAY_BUFFER,0);
	glBindVertexArray(0);
	m_shader_flat->stopUseProgram();

	glDisable(GL_POLYGON_OFFSET_FILL);

	m_shader_color->startUseProgram();
	m_shader_color->sendViewMatrix(viewMatrix);
	m_shader_color->sendProjectionMatrix(projectionMatrix);
	glUniform3f(m_shader_color->idOfColorUniform, 0.0f,0.0f,0.0f);
	glBindVertexArray(m_vao2);
	glBindBuffer(GL_ELEMENT_ARRAY_BUFFER,m_ebo2);
	glDrawElements(GL_LINES, m_nb_ind_edges,GL_UNSIGNED_INT,0);
	glBindBuffer(GL_ELEMENT_ARRAY_BUFFER,0);
	glBindVertexArray(0);
	m_shader_color->stopUseProgram();
}

void MeshQuad::clear()
{
	m_points.clear();
	m_quad_indices.clear();
}

int MeshQuad::add_vertex(const Vec3& P)
{
    m_points.push_back(P);
    return m_points.size()-1;
}


void MeshQuad::add_quad(int i1, int i2, int i3, int i4)
{
    m_quad_indices.push_back(i1);
    m_quad_indices.push_back(i2);
    m_quad_indices.push_back(i3);
    m_quad_indices.push_back(i4);
}

void MeshQuad::convert_quads_to_tris(const std::vector<int>& quads, std::vector<int>& tris)
{
	tris.clear();
	tris.reserve(3*quads.size()/2); // 1 quad = 4 indices -> 2 tris = 6 indices d'ou ce calcul (attention division entiere)

	// Pour chaque quad on genere 2 triangles
	// Attention a respecter l'orientation des triangles
    for(int i = 0; i < (int)quads.size(); i++){ // Un polyèdre à N sommets contient (N-2)/2 carrés
        tris.push_back(quads[i*4]);
        tris.push_back(quads[i*4+1]);
        tris.push_back(quads[i*4+2]);

        tris.push_back(quads[i*4]);
        tris.push_back(quads[i*4+2]);
        tris.push_back(quads[i*4+3]);
    }
}

void MeshQuad::convert_quads_to_edges(const std::vector<int>& quads, std::vector<int>& edges)
{

    auto alreadyStored = [&] (int i) -> bool
    {
         int idx = (i+1)%4;

         for(int j = 0; j < (int)edges.size(); j++){
             if(edges[j] == quads[idx] && edges[j+1] == quads[i])
                 return true;
         }
         return false;
    };

	edges.clear();
	edges.reserve(quads.size()); // ( *2 /2 !)

	// Pour chaque quad on genere 4 aretes, 1 arete = 2 indices.
	// Mais chaque arete est commune a 2 quads voisins !
	// Comment n'avoir qu'une seule fois chaque arete ?

    for(int i = 0; i < (int)quads.size(); i+=4){
        //On vérifie que l'arête inverse n'est pas déjà présente
        // Avant de l'ajouter à edges

        if(!alreadyStored(i)){
            edges.push_back(quads[i]);
            edges.push_back(quads[i+1]);
        }

        if(!alreadyStored(i+1)){
            edges.push_back(quads[i+1]);
            edges.push_back(quads[i+2]);
        }

        if(!alreadyStored(i+2)){
            edges.push_back(quads[i+2]);
            edges.push_back(quads[i+3]);
        }

        if(!alreadyStored(i+3)){
            edges.push_back(quads[i+3]);
            edges.push_back(quads[i]);
        }
    }

}


void MeshQuad::create_cube()
{
	clear();
	// ajouter 8 sommets (-1 +1)
    int s1 = add_vertex(Vec3(0,0,0));
    int s2 = add_vertex(Vec3(0.5,0,0));
       int s3 = add_vertex(Vec3(0.5,0.5,0));
       int s4 = add_vertex(Vec3(0,0.5,0));
       int s5 = add_vertex(Vec3(0,0,0.5));
       int s6 = add_vertex(Vec3(0.5,0,0.5));
       int s7 = add_vertex(Vec3(0.5,0.5,0.5));
       int s8 = add_vertex(Vec3(0,0.5,0.5));

       // ajouter 6 faces (sens trigo)
       add_quad(s1,s4,s3,s2);
       add_quad(s1,s2,s6,s5);
       add_quad(s2,s3,s7,s6);
       add_quad(s1,s5,s8,s4);
       add_quad(s4,s8,s7,s3);
       add_quad(s5,s6,s7,s8);

	gl_update();
}



Vec3 MeshQuad::normal_of_quad(const Vec3& A, const Vec3& B, const Vec3& C, const Vec3& D)
{
	// Attention a l'ordre des points !
	// le produit vectoriel n'est pas commutatif U ^ V = - V ^ U
	// ne pas oublier de normaliser le resultat.

    //Normale AB^AC
    Vec3 AB = B-A;
    Vec3 AC =C-A;
    Vec3 n1 = glm::cross(AB,AC);

    //Normale CD^CA
    Vec3 CD = D-C;
    Vec3 CA = A-C;
    Vec3 n2 = glm::cross(CD,CA);

    //Moyenne des 2 puis normalisation du vecteur en résultant
    Vec3 n = (n1+n2)/2.0f;

    Vec3 QuadNormal = glm::normalize(n);

    return QuadNormal;

}



float MeshQuad::area_of_quad(const Vec3& A, const Vec3& B, const Vec3& C, const Vec3& D)
{
	// aire du quad - aire tri + aire tri

	// aire du tri = 1/2 aire parallelogramme

	// aire parallelogramme: cf produit vectoriel

    //Aire ABC
    Vec3 ab = B-A;
    Vec3 bc = C-B;

    float aire_P1 = glm::length(glm::cross(ab,bc))/2;

    //Aire ACD
    Vec3 cd = D-C;
    Vec3 da = A-D;

    float aire_P2 = glm::length(glm::cross(cd,da))/2;

    //Aire ABCD
    return (aire_P1 + aire_P2);
}


bool MeshQuad::is_points_in_quad(const Vec3& P, const Vec3& A, const Vec3& B, const Vec3& C, const Vec3& D)
{
	// On sait que P est dans le plan du quad.

	// P est-il au dessus des 4 plans contenant chacun la normale au quad et une arete AB/BC/CD/DA ?
	// si oui il est dans le quad

    Vec3 normale_quad = normal_of_quad(A,B,C,D);
    // Plan parallèle à la normale n du quad passant par AB
        // Calcul de la normale v du plan
    Vec3 AB = B-A;
    Vec3 normale_plan = glm::normalize(glm::cross(normale_quad,AB));


        // Calcul de la distance entre le point P et le plan passant par AB -> si distance > 0, alors
        // P est au dessus du plan
    Vec3 AP = P-A;
    float distance = glm::dot(normale_plan, AP)/glm::length(normale_plan);

    if(distance < 0)
        return false;

    else{
        // Plan parallèle à la normale n du quad passant par BC
            // Calcul de la normale v du plan
        Vec3 BC = C-B;
        normale_plan = glm::normalize(glm::cross(normale_quad,BC));

            // Calcul de la distance entre le point P et le plan passant par BC -> si distance > 0, alors
            // P est au dessus du plan
        Vec3 BP = P-B;
        distance = glm::dot(normale_plan, BP)/glm::length(normale_plan);

        if(distance < 0)
            return false;

        else{

            // Plan parallèle à la normale n du quad passant par CD
                // Calcul de la normale v du plan
            Vec3 CD = D-C;
            normale_plan = glm::normalize(glm::cross(normale_quad,CD));

                // Calcul de la distance entre le point P et le plan passant par CD -> si distance > 0, alors
                // P est au dessus du plan
            Vec3 CP = P-C;
            distance = glm::dot(normale_plan, CP)/glm::length(normale_plan);

            if(distance < 0)
                return false;

            else{

                // Plan parallèle à la normale n du quad passant par DA
                    // Calcul de la normale v du plan
                Vec3 DA = A-D;
                normale_plan = glm::normalize(glm::cross(normale_quad,DA));

                    // Calcul de la distance entre le point P et le plan passant par DA -> si distance > 0, alors
                    // P est au dessus du plan
                Vec3 AP = P-A;
                distance = glm::dot(normale_plan, AP)/glm::length(normale_plan);

                if(distance < 0)
                    return false;
            }
        }
    }

	return true;
}

bool MeshQuad::intersect_ray_quad(const Vec3& P, const Vec3& Dir, int q, Vec3& inter)
{
	// recuperation des indices de points
    int indA = m_quad_indices[q*4];
    int indB = m_quad_indices[q*4+1];
    int indC = m_quad_indices[q*4+2];
    int indD = m_quad_indices[q*4+3];
	// recuperation des points
    Vec3 A = m_points[indA];
    Vec3 B = m_points[indB];
    Vec3 C = m_points[indC];
    Vec3 D = m_points[indD];


    // calcul de l'equation du plan (N+d)
    Vec3 N = normal_of_quad(A,B,C,D);
    float d = -dot(A,N);

	// calcul de l'intersection rayon plan
	// I = P + alpha*Dir est dans le plan => calcul de alpha

    //On vérifie qu'il y ait intersection
    if(glm::dot(N,Dir) != 0){

        float alpha = (-d-glm::dot(N,P))/glm::dot(N,Dir);

        // alpha => calcul de I
        inter = Dir;
        inter.x *= alpha;
        inter.y *= alpha;
        inter.z *= alpha;

        inter.x += P.x;
        inter.y += P.y;
        inter.z =+ P.z;

    }
    else{
        return false;
    }
	// I dans le quad ?
    return is_points_in_quad(inter,A,B,C,D);

}


int MeshQuad::intersected_visible(const Vec3& P, const Vec3& Dir)
{
    int inter = -1;
    int min_dist = (int)INFINITY;
	// on parcours tous les quads
    for(int i = 0; i < (int)m_quad_indices.size()/4; i++){

        Vec3 Intersection;
        // on teste si il y a intersection avec le rayon + modification de Intersection par effet de bord
        if(intersect_ray_quad(P,Dir,i,Intersection)){

                // recuperation des indices de points
                int indA = m_quad_indices[i*4];
                int indB = m_quad_indices[i*4+1];
                int indC = m_quad_indices[i*4+2];
                int indD = m_quad_indices[i*4+3];
                // recuperation des points
                Vec3 A = m_points[indA];
                Vec3 B = m_points[indB];
                Vec3 C = m_points[indC];
                Vec3 D = m_points[indD];

                //Calcul normale du quad && distance algébrique de P à l'intersection
                Vec3 normale_quad = normal_of_quad(A,B,C,D);
                Vec3 P_Intersection = Intersection-P;
                float distance = glm::dot(normale_quad, P_Intersection)/glm::length(normale_quad);

                // Si la distance algébrique entre P et son intersection avec le quad courant est la plus petite trouvée
                // jusqu'à maintenant, inter prend la valeur de l'indice du quad courant
                if(min_dist > distance){
                    inter = i;
                    min_dist = distance;
                }
         }
    }

	// on garde le plus proche (de P)

	return inter;
}


Mat4 MeshQuad::local_frame(int q)
{
	// recuperation des indices de points
    int indA = m_quad_indices[q*4];
    int indB = m_quad_indices[q*4+1];
    int indC = m_quad_indices[q*4+2];
    int indD = m_quad_indices[q*4+3];
     // recuperation des points
    Vec3 A = m_points[indA];
    Vec3 B = m_points[indB];
    Vec3 C = m_points[indC];
    Vec3 D = m_points[indD];
	// Repere locale = Matrice de transfo avec
	// les trois premieres colonnes: X,Y,Z locaux
	// la derniere colonne l'origine du repere

	// ici Z = N et X = AB
	// Origine le centre de la face
    // longueur des axes : [AB]/2

	// calcul de Z:N puis de X:arete on en deduit Y
    Vec3 ZVec3 = normal_of_quad(A,B,C,D);
    Vec3 XVec3 = B-A;
    Vec3 YVec3 = D-A;

    // calcul de la taille
    double length = glm::length(XVec3)/2;

    // Conversion en Vec4
    glm::vec4 Z(ZVec3, 0);
    glm::vec4 Y(YVec3, 0);
    glm::vec4 X(XVec3, 0);

	// calcul du centre
    Vec3 midABC = (A+B+C)/3.0f;
    Vec3 midACD = (A+C+D)/3.0f;
    Vec3 PVec3 = (midABC + midACD)/2.0f;
    glm::vec4 P(PVec3,1);

	// calcul de la matrice
    Mat4 matrice = glm::mat4(X,Y,Z,P);
    const auto AB_scale = scale(length,length,length);
    matrice*=AB_scale;


    return matrice;
}

void MeshQuad::extrude_quad(int q)
{
    // recuperation des indices de points
    int indA = m_quad_indices[q*4];
    int indB = m_quad_indices[q*4+1];
    int indC = m_quad_indices[q*4+2];
    int indD = m_quad_indices[q*4+3];
     // recuperation des points
    Vec3 A = m_points[indA];
    Vec3 B = m_points[indB];
    Vec3 C = m_points[indC];
    Vec3 D = m_points[indD];

	// calcul de la normale
    Vec3 normale = normal_of_quad(A,B,C,D);

	// calcul de la hauteur
    float hauteur = sqrt(area_of_quad(A,B,C,D));

	// calcul et ajout des 4 nouveaux points
    Vec3 newA = A+hauteur*normale;
    Vec3 newB = B+hauteur*normale;
    Vec3 newC = C+hauteur*normale;
    Vec3 newD = D+hauteur*normale;


    // on remplace le quad initial par le quad du dessus
    int idxNewA = add_vertex(newA);
    int idxNewB = add_vertex(newB);
    int idxNewC = add_vertex(newC);
    int idxNewD = add_vertex(newD);

    m_quad_indices[q*4] = idxNewA;
    m_quad_indices[q*4+1] = idxNewB;
    m_quad_indices[q*4+2] = idxNewC;
    m_quad_indices[q*4+3] = idxNewD;

	// on ajoute les 4 quads des cotes

    add_quad(indA, indB, idxNewB, idxNewA);
    add_quad(indB, indC, idxNewC, idxNewB);
    add_quad(indC, indD, idxNewD, idxNewC);
    add_quad(indD, indA, idxNewA, idxNewD);

	gl_update();
}


void MeshQuad::decale_quad(int q, float d)
{
	// recuperation des indices de points
    int indA = m_quad_indices[q*4];
    int indB = m_quad_indices[q*4+1];
    int indC = m_quad_indices[q*4+2];
    int indD = m_quad_indices[q*4+3];
	// recuperation des (references de) points
    Vec3 A = m_points[indA];
    Vec3 B = m_points[indB];
    Vec3 C = m_points[indC];
    Vec3 D = m_points[indD];
	// calcul de la normale
    Vec3 normale = normal_of_quad(A,B,C,D);

	// modification des points
    m_points[indA] = A + (normale*d);
    m_points[indB] = B + (normale*d);
    m_points[indC] = C + (normale*d);
    m_points[indD] = D + (normale*d);

	gl_update();
}


void MeshQuad::shrink_quad(int q, float s)
{
    // recuperation des indices de points
    int indA = m_quad_indices[q*4];
    int indB = m_quad_indices[q*4+1];
    int indC = m_quad_indices[q*4+2];
    int indD = m_quad_indices[q*4+3];
    // recuperation des (references de) points
    Vec3 A = m_points[indA];
    Vec3 B = m_points[indB];
    Vec3 C = m_points[indC];
    Vec3 D = m_points[indD];
	// ici  pas besoin de passer par une matrice
    // calcul du centre
    Vec3 midABC = (A+B+C)/3.0f;
    Vec3 midACD = (A+C+D)/3.0f;
    Vec3 P = midABC + (midACD-midABC)/2.0f;

	 // modification des points
    m_points[indA] = A + (s*(P-A));
    m_points[indB] = B + (s*(P-B));
    m_points[indC] = C + (s*(P-C));
    m_points[indD] = D + (s*(P-D));

	gl_update();
}


void MeshQuad::tourne_quad(int q, float a)
{
    // recuperation des indices de points
    int indA = m_quad_indices[q*4];
    int indB = m_quad_indices[q*4+1];
    int indC = m_quad_indices[q*4+2];
    int indD = m_quad_indices[q*4+3];
    // recuperation des (references de) points
    glm::vec4 A(m_points[indA],1);
    glm::vec4 B(m_points[indB],1);
    glm::vec4 C(m_points[indC],1);
    glm::vec4 D(m_points[indD],1);

	// generation de la matrice de transfo:
    // tourne autour du Z de la local frame
	// indice utilisation de glm::inverse()

	// Application au 4 points du quad
    Mat4 localRepMat = local_frame(q);
    Mat4 matTourne = localRepMat*rotateZ(a)*glm::inverse(localRepMat);

    A = matTourne*A;
    Vec3 newA = glm::vec3(A.x,A.y,A.z);
    m_points[indA] = newA;

    B = matTourne*B;
    Vec3 newB = glm::vec3(B.x,B.y,B.z);
    m_points[indB] = newB;

    C = matTourne*C;
    Vec3 newC = glm::vec3(C.x,C.y,C.z);
    m_points[indC] = newC;

    D = matTourne*D;
    Vec3 newD = glm::vec3(D.x,D.y,D.z);
    m_points[indD] = newD;

	gl_update();
}

void MeshQuad::create_spirale(){

    create_cube();
    local_frame(0);
    int nbQuads;
    for(int i = 0; i < 150; i++){

        extrude_quad(0);

        nbQuads = m_quad_indices.size()/4;

        tourne_quad(nbQuads-4, 10);
        tourne_quad(nbQuads-2, -10);
        decale_quad(nbQuads-4, -0.05);
        decale_quad(nbQuads-2, 0.05);
        shrink_quad(0, 0.005);
    }

}

void MeshQuad::create_etoile(){

    create_cube();
    local_frame(0);

    for(int i = 0; i < 6; i++){

        for(int j = 0; j < 20; j++){

            extrude_quad(i);
            tourne_quad(i, 10);
            shrink_quad(i, 0.1);
        }
    }

}

// create_recursive_etoile() : non fonctionnelle
void MeshQuad::create_recursive_etoile(int q, int p){

    if(p > 0){
        extrude_quad(q);
        shrink_quad(q, 0.5);
        extrude_quad(q);

        int nbQuads = m_quad_indices.size()/4;

        for(int i = 0; i < 5; i++){
            create_recursive_etoile(nbQuads-1-i, p-1);
        }
    }


}

